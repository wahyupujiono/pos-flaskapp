class Config(object):
	SQLALCHEMY_DATABASE_URI = 'mysql://root:root@localhost/pos'
	SQLALCHEMY_TRACK_MODIFICATIONS = False
